var Tx = require('ethereumjs-tx');
const Web3 = require('web3');
const Web3utils = require('web3-utils')
// const Web3 = require('web3-utils')
const web3 = new Web3(new Web3.providers.HttpProvider('https://ropsten.infura.io/v3/49ec18cc3e22418f9c8901d695d68f44'));

const account1 = '0xDc0ba17b3FD674F8372df48B84CB6b75f5451C0B' // Your account address 1
const account2 = '0x7A03C24D58A19D27A66dBa7769573A0E7FDF3989' // Your account address 2

const privateKey1 = Buffer.from('F1B231303267FCFD236E279BA712CD457E5D917871FD25A414107618BFAD8120', 'hex');
// const privateKey2 = Buffer.from('', 'hex');


// Signs the given transaction data and sends it. Abstracts some of the details 
// of buffering and serializing the transaction for web3.
// function sendSigned(txData, cb) {
//   const privateKey = new Buffer(config.privateKey1, 'hex')
//   const transaction = new Tx(txData)
//   transaction.sign(privateKey)
//   const serializedTx = transaction.serialize().toString('hex')
//   web3.eth.sendSignedTransaction('0x' + serializedTx, cb)
// }

web3.eth.getTransactionCount(account1, (err, txCount) => {
  // if(err)
    // throw err;
  // Build the transaction
  const txObject = {
    nonce: Web3utils.toHex(txCount),
    to: account2,
    value: Web3utils.toHex(Web3utils.toWei('0.1', 'ether')),
    gasLimit: Web3utils.toHex(21000),
    gasPrice: Web3utils.toHex(Web3utils.toWei('10', 'gwei'))
  }

  // Sign the transaction
  const tx = new Tx(txObject);
  tx.sign(privateKey1);

  const serializedTx = tx.serialize();
  const raw = '0x' + serializedTx.toString('hex');

  // Broadcast the transaction
  web3.eth.sendSignedTransaction(raw, (err, txHash) => {
    console.log('txHash:', txHash);
    // Now go check etherscan to see the transaction!
  });
});
