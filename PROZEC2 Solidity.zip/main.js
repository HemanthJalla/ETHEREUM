var fromAddress = req.body[0].from;
    var toAddress = req.body[0].to;

    var count = web3.eth.getTransactionCount(fromAddress);
    var pKey1 = req.body[0].privateKey;
    var value = req.body[0].value;
    var pKey1x = Buffer.from(pKey1, 'hex');

    var rawTx = {
        "form": fromAddress,
        "nonce": web3.toHex(count),
        "gasPrice": gasPrice,
        "gasLimit": gasLimit,
        "to": tokenAddress,
        "value": 0x0,
        "data": contract.transfer.getData(toAddress, web3.toWei(value, 'ether')),
        "chainId": "0x03"
    };

    var tx = new EthTx(rawTx);
    tx.sign(pKey1x);

    var serializeTx = tx.serialize();

    web3.eth.sendRawTransaction('0x' + serializeTx.toString('hex'), (error, result) => {
        if (!error) {
            console.log("Transaction ID", result);
        } else {
            console.log(error,"Token Cannot be sent.");
        }
        var str = [{"transactionId": result}];
        res.send(JSON.stringify(str));
    });
