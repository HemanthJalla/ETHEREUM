var Tx     = require('ethereumjs-tx');
const Web3 = require('web3');
var Web3Utils = require('web3-utils');

const web3 = new Web3 (new Web3.providers.HttpProvider('https://ropsten.infura.io/v3/49ec18cc3e22418f9c8901d695d68f44'));
var fromAddress = "0xDc0ba17b3FD674F8372df48B84CB6b75f5451C0B";
var toAddress = ["0xb5e77a7F21F5a063D35731535B4D538A25747C49", "0xfFBC7C100364F68B45c754eee47EF93ff14c1882", "0x440E50C4aA3742092eBd328A084DBF8935d6243f", "0xC0BCdE4dC1703Ec9318e4305D11007f65F63d9B4", "0xFA551AED7973a00D016E49405B8b9ae3394B544F", "0x0213210705f16e45fDcc7910d6fe0fb203C30eAD"];
for(i = 0; i< toAddress.length; i++) {
    var count = web3.eth.getTransactionCount(fromAddress);
    // var abiArray = JSON.parse(fs.readFileSync('coin.json', 'utf-8'));
    var coursesContract = web3.eth.contract([
        {
            "constant": false,
            "inputs": [
                {
                    "name": "_spender",
                    "type": "address"
                },
                {
                    "name": "_amount",
                    "type": "uint256"
                }
            ],
            "name": "approve",
            "outputs": [
                {
                    "name": "success",
                    "type": "bool"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "nonpayable"
        },
        {
            "constant": false,
            "inputs": [
                {
                    "name": "_to",
                    "type": "address"
                },
                {
                    "name": "_amount",
                    "type": "uint256"
                }
            ],
            "name": "transfer",
            "outputs": [
                {
                    "name": "success",
                    "type": "bool"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "nonpayable"
        },
        {
            "constant": false,
            "inputs": [
                {
                    "name": "_from",
                    "type": "address"
                },
                {
                    "name": "_to",
                    "type": "address"
                },
                {
                    "name": "_amount",
                    "type": "uint256"
                }
            ],
            "name": "transferFrom",
            "outputs": [
                {
                    "name": "success",
                    "type": "bool"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "nonpayable"
        },
        {
            "inputs": [],
            "payable": false,
            "type": "constructor",
            "stateMutability": "nonpayable"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "name": "_from",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "name": "_to",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "name": "_value",
                    "type": "uint256"
                }
            ],
            "name": "Transfer",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "name": "_owner",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "name": "_spender",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "name": "_value",
                    "type": "uint256"
                }
            ],
            "name": "Approval",
            "type": "event"
        },
        {
            "constant": true,
            "inputs": [
                {
                    "name": "_owner",
                    "type": "address"
                },
                {
                    "name": "_spender",
                    "type": "address"
                }
            ],
            "name": "allowance",
            "outputs": [
                {
                    "name": "remaining",
                    "type": "uint256"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        },
        {
            "constant": true,
            "inputs": [
                {
                    "name": "_owner",
                    "type": "address"
                }
            ],
            "name": "balanceOf",
            "outputs": [
                {
                    "name": "balance",
                    "type": "uint256"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        },
        {
            "constant": true,
            "inputs": [],
            "name": "decimals",
            "outputs": [
                {
                    "name": "",
                    "type": "uint8"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        },
        {
            "constant": true,
            "inputs": [],
            "name": "name",
            "outputs": [
                {
                    "name": "",
                    "type": "string"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        },
        {
            "constant": true,
            "inputs": [],
            "name": "owner",
            "outputs": [
                {
                    "name": "",
                    "type": "address"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        },
        {
            "constant": true,
            "inputs": [],
            "name": "symbol",
            "outputs": [
                {
                    "name": "",
                    "type": "string"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        },
        {
            "constant": true,
            "inputs": [],
            "name": "totalSupply",
            "outputs": [
                {
                    "name": "totalSupply",
                    "type": "uint256"
                }
            ],
            "payable": false,
            "type": "function",
            "stateMutability": "view"
        }
    ])
    var contractAddress = "0xf52a47a51260636102c6caed04fdb909b46768b3";
    var contract = web3.eth.contract(coursesContract.abi).at(contractAddress);
    // console.log("-----"+result);
    var rawTransaction = {
        "from": fromAddress,
        "nonce": Web3Utils.toHex(count),
        "gasPrice": Web3Utils.toHex(Web3Utils.toWei('2', 'gwei')),
        "gasLimit": Web3Utils.toHex(210000),
        "to": contractAddress,
        "value": 0x0,
        "data": contract.transfer.getData(toAddress[i], Web3Utils.toWei('10', 'ether')),
        "chainId": "0x03"
    };
    
    var privKey = new Buffer('F1B231303267FCFD236E279BA712CD457E5D917871FD25A414107618BFAD8120', 'hex');
    var tx = new Tx(rawTransaction);
    
    tx.sign(privKey);
    var serializedTx = tx.serialize();
    
    web3.eth.sendRawTransaction('0x' + serializedTx.toString('hex'), function(err, hash) {
        if (!err)
            console.log(hash);
        else
            console.log(err);
    });
}