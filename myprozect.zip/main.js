//how to transfer ETHER from account to another account
var Tx     = require('ethereumjs-tx')
const Web3 = require('web3')
var Web3Utils = require('web3-utils')

const web3 = new Web3 (new Web3.providers.HttpProvider('https://ropsten.infura.io/v3/49ec18cc3e22418f9c8901d695d68f44'));

const account1 = '0xDc0ba17b3FD674F8372df48B84CB6b75f5451C0B' // Your account address 1
const account2 = '0x7A03C24D58A19D27A66dBa7769573A0E7FDF3989' // Your account address 2

const privateKey1 = Buffer.from('F1B231303267FCFD236E279BA712CD457E5D917871FD25A414107618BFAD8120', 'hex')
// const privateKey2 = Buffer.from('', 'hex')


web3.eth.getTransactionCount(account1, (err, txCount) => {
  // Build the transaction
  const txObject = {
    nonce:    Web3Utils.toHex(txCount),
    to:       account2,
    value:    Web3Utils.toHex(Web3Utils.toWei('0.1', 'ether')),
    gasLimit: Web3Utils.toHex(21000),
    gasPrice: Web3Utils.toHex(Web3Utils.toWei('10', 'gwei'))
  }

  // Sign the transaction
  const tx = new Tx(txObject)
  tx.sign(privateKey1)

  const serializedTx = tx.serialize()
  const raw = '0x' + serializedTx.toString('hex')

  // Broadcast the transaction
  web3.eth.sendRawTransaction(raw, (err, txHash) => {
    console.log('txHash:', txHash)
    // Now go check etherscan to see the transaction!
  })
})